﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    public class Chercheurs
    {
        private int id_chercheur;         // Identifiant unique du matériel
        private string prenom;           // Type de matériel
        private string nom;          // Mémoire du matériel
        private string specialite;       // Processeur du matériel
        private string annee;         // Logiciel installé sur le matériel

        public Chercheurs(string prenom,string nom , string specialite,string annee)
        {
            
            this.nom = nom;
            this.prenom = prenom;
            this.specialite = specialite;   
            this.annee = annee;

        }

        public Chercheurs(int id_chercheur,string prenom, string nom, string specialite, string annee)
        {
            this.id_chercheur = id_chercheur;

            this.nom = nom;
            this.prenom = prenom;
            this.specialite = specialite;
            this.annee = annee;

        }
        public int getId_chercheur()
        {
            return id_chercheur; 
        }


        public string getPrenom()
        {
            return prenom;
        }


        public string getNom()
        {
            return nom;
        }

        public string getSpecialite()
        {
            return specialite;
        }

        public void SetSpecilite(string specilite)
        {
            this.specialite = specilite;
        }
        public string GetAnnee()
            { return annee; }


    }
}
