﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente un ticket de support ou une demande dans le système.
    /// </summary>
    public class Ticket
    {
        // Attributs privés de la classe Ticket
        private int id_ticket;           // Identifiant unique du ticket
        private string urgence;          // Urgence du ticket (niveau de priorité)
        private string etat;             // État du ticket (ouvert, fermé, en cours, etc.)
        private string type_demande;     // Type de demande (catégorie du ticket)
        private string date_ticket;      // Date à laquelle le ticket a été créé
        private int idtechnicien;        // Identifiant du technicien assigné au ticket
        private string id_materiel;      // Identifiant du matériel lié au ticket
        private string matricule;        // Matricule de la personne ayant créé ou rapporté le ticket
        private string description;      // Description du problème ou de la demande

        /// <summary>
        /// Constructeur pour initialiser un nouveau ticket avec des valeurs fournies.
        /// </summary>
        /// <param name="id_ticket">Identifiant du ticket.</param>
        /// <param name="urgence">Urgence du ticket (niveau de priorité).</param>
        /// <param name="etat">État du ticket (ouvert, fermé, en cours, etc.).</param>
        /// <param name="type_demande">Type de demande (catégorie du ticket).</param>
        /// <param name="date_ticket">Date de création du ticket.</param>
        /// <param name="idtechnicien">Identifiant du technicien assigné.</param>
        /// <param name="id_materiel">Identifiant du matériel concerné par le ticket.</param>
        /// <param name="matricule">Matricule de la personne ayant rapporté le ticket.</param>
        /// <param name="description">Description détaillée du problème ou de la demande.</param>
        public Ticket(int id_ticket, string urgence, string etat, string type_demande, string date_ticket, int idtechnicien, string id_materiel, string matricule, string description)
        {
            this.id_ticket = id_ticket;          // Assigne l'ID du ticket
            this.urgence = urgence;              // Assigne le niveau d'urgence
            this.etat = etat;                    // Assigne l'état du ticket
            this.type_demande = type_demande;    // Assigne le type de demande
            this.date_ticket = date_ticket;      // Assigne la date de création du ticket
            this.idtechnicien = idtechnicien;    // Assigne l'ID du technicien responsable
            this.id_materiel = id_materiel;      // Assigne l'ID du matériel concerné
            this.matricule = matricule;          // Assigne le matricule de la personne rapportant le ticket
            this.description = description;      // Assigne la description du problème ou de la demande
        }

        /// <summary>
        /// Constructeur pour initialiser un ticket sans identifiant, avec les autres informations.
        /// </summary>
        /// <param name="urgence">Urgence du ticket (niveau de priorité).</param>
        /// <param name="etat">État du ticket (ouvert, fermé, en cours, etc.).</param>
        /// <param name="type_demande">Type de demande (catégorie du ticket).</param>
        /// <param name="date_ticket">Date de création du ticket.</param>
        /// <param name="idtechnicien">Identifiant du technicien assigné.</param>
        /// <param name="id_materiel">Identifiant du matériel concerné par le ticket.</param>
        /// <param name="matricule">Matricule de la personne ayant rapporté le ticket.</param>
        /// <param name="description">Description détaillée du problème ou de la demande.</param>
        public Ticket(string urgence, string etat, string type_demande, string date_ticket, int idtechnicien, string id_materiel, string matricule, string description)
        {
            this.urgence = urgence;              // Assigne le niveau d'urgence
            this.etat = etat;                    // Assigne l'état du ticket
            this.type_demande = type_demande;    // Assigne le type de demande
            this.date_ticket = date_ticket;      // Assigne la date de création du ticket
            this.idtechnicien = idtechnicien;    // Assigne l'ID du technicien responsable
            this.id_materiel = id_materiel;      // Assigne l'ID du matériel concerné
            this.matricule = matricule;          // Assigne le matricule de la personne rapportant le ticket
            this.description = description;      // Assigne la description du problème ou de la demande
        }

        public Ticket(string urgence, string etat, string type_demande, string date_ticket)
        {
            this.urgence = urgence;              // Assigne le niveau d'urgence
            this.etat = etat;                    // Assigne l'état du ticket
            this.type_demande = type_demande;    // Assigne le type de demande
            this.date_ticket = date_ticket;      // Assigne la date de création du ticket
        }
        // Méthodes getter et setter pour chaque attribut

        /// <summary>
        /// Retourne l'identifiant du ticket.
        /// </summary>
        /// <returns>L'identifiant du ticket.</returns>
        public int GetIdTicket()
        {
            return id_ticket;
        }

        /// <summary>
        /// Modifie l'identifiant du ticket.
        /// </summary>
        /// <param name="unidticket">Nouvel identifiant du ticket.</param>
        public void SetIdTicket(int unidticket)
        {
            id_ticket = unidticket;
        }

        /// <summary>
        /// Retourne l'urgence du ticket.
        /// </summary>
        /// <returns>Le niveau d'urgence du ticket.</returns>
        public string GetUrgence()
        {
            return urgence;
        }

        /// <summary>
        /// Modifie l'urgence du ticket.
        /// </summary>
        /// <param name="uneurgence">Nouveau niveau d'urgence pour le ticket.</param>
        public void SetUrgence(string uneurgence)
        {
            urgence = uneurgence;
        }

        /// <summary>
        /// Retourne l'état du ticket.
        /// </summary>
        /// <returns>L'état actuel du ticket.</returns>
        public string GetEtat()
        {
            return etat;
        }

        /// <summary>
        /// Modifie l'état du ticket.
        /// </summary>
        /// <param name="unetat">Nouvel état pour le ticket.</param>
        public void SetEtat(string unetat)
        {
            etat = unetat;
        }

        /// <summary>
        /// Retourne le type de demande du ticket.
        /// </summary>
        /// <returns>Le type de demande du ticket.</returns>
        public string GetTypeDemande()
        {
            return type_demande;
        }

        /// <summary>
        /// Modifie le type de demande du ticket.
        /// </summary>
        /// <param name="untype">Nouveau type de demande pour le ticket.</param>
        public void SetTypeDemande(string untype)
        {
            type_demande = untype;
        }

        /// <summary>
        /// Retourne la date de création du ticket.
        /// </summary>
        /// <returns>La date de création du ticket.</returns>
        public string GetDateTicket()
        {
            return date_ticket;
        }

        /// <summary>
        /// Modifie la date de création du ticket.
        /// </summary>
        /// <param name="uneDate">Nouvelle date de création du ticket.</param>
        public void SetDateTicket(string uneDate)
        {
            date_ticket = uneDate;
        }

        /// <summary>
        /// Retourne l'identifiant du technicien assigné au ticket.
        /// </summary>
        /// <returns>L'identifiant du technicien assigné au ticket.</returns>
        public int GetIdTechnicien()
        {
            return idtechnicien;
        }

        /// <summary>
        /// Modifie l'identifiant du technicien assigné au ticket.
        /// </summary>
        /// <param name="unidtech">Nouvel identifiant pour le technicien assigné.</param>
        public void SetIdTechnicien(int unidtech)
        {
            idtechnicien = unidtech;
        }

        /// <summary>
        /// Retourne l'identifiant du matériel lié au ticket.
        /// </summary>
        /// <returns>L'identifiant du matériel concerné par le ticket.</returns>
        public string GetIdMateriel()
        {
            return id_materiel;
        }

        /// <summary>
        /// Modifie l'identifiant du matériel lié au ticket.
        /// </summary>
        /// <param name="unidmat">Nouvel identifiant pour le matériel lié au ticket.</param>
        public void SetIdMateriel(string unidmat)
        {
            id_materiel = unidmat;
        }

        /// <summary>
        /// Retourne le matricule de la personne ayant rapporté le ticket.
        /// </summary>
        /// <returns>Le matricule de la personne ayant rapporté le ticket.</returns>
        public string GetMatricule()
        {
            return matricule;
        }

        /// <summary>
        /// Retourne la description du ticket.
        /// </summary>
        /// <returns>La description détaillée du problème ou de la demande.</returns>
        public string GetDescription()
        {
            return description;
        }

        /// <summary>
        /// Modifie le matricule de la personne ayant rapporté le ticket.
        /// </summary>
        /// <param name="unmatricule">Nouveau matricule pour la personne ayant rapporté le ticket.</param>
        public void SetMatricule(string unmatricule)
        {
            matricule = unmatricule;
        }

        /// <summary>
        /// Modifie la description du ticket.
        /// </summary>
        /// <param name="unedescription">Nouvelle description pour le ticket.</param>
        public void SetDescription(string unedescription)
        {
            description = unedescription;
        }
    }
}
