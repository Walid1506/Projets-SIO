﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente un technicien dans le système.
    /// </summary>
    public class Technicien
    {
        private string id_technicien;
        private string niveau_intervention;
        private string formationT;
        private string mdp;

        /// <summary>
        /// Constructeur pour initialiser un technicien avec un identifiant, un niveau d'intervention, une formation et un mot de passe.
        /// </summary>
        /// <param name="id_technicien">L'identifiant unique du technicien.</param>
        /// <param name="niveau_intervention">Le niveau d'intervention du technicien.</param>
        /// <param name="formationT">La formation du technicien.</param>
        /// <param name="mdp">Le mot de passe du technicien.</param>
        public Technicien(string id_technicien, string niveau_intervention, string formationT, string mdp)
        {
            this.id_technicien = id_technicien;
            this.niveau_intervention = niveau_intervention;
            this.formationT = formationT;
            this.mdp = mdp;
        }

        /// <summary>
        /// Constructeur pour initialiser un technicien avec un niveau d'intervention, une formation et un mot de passe.
        /// </summary>
        /// <param name="niveau_intervention">Le niveau d'intervention du technicien.</param>
        /// <param name="formationT">La formation du technicien.</param>
        /// <param name="mdp">Le mot de passe du technicien.</param>
        public Technicien(string niveau_intervention, string formationT, string mdp)
        {
            this.niveau_intervention = niveau_intervention;
            this.formationT = formationT;
            this.mdp = mdp;
        }

        /// <summary>
        /// Constructeur pour initialiser un technicien avec une formation et un mot de passe.
        /// </summary>
        /// <param name="formationT">La formation du technicien.</param>
        /// <param name="mdp">Le mot de passe du technicien.</param>
        public Technicien(string formationT, string mdp)
        {
            this.formationT = formationT;
            this.mdp = mdp;
        }

        /// <summary>
        /// Obtient l'identifiant du technicien.
        /// </summary>
        /// <returns>L'identifiant du technicien.</returns>
        public string GetIdTechnicien()
        {
            return id_technicien;
        }

        /// <summary>
        /// Modifie l'identifiant du technicien.
        /// </summary>
        /// <param name="unid_technicien">Le nouvel identifiant du technicien.</param>
        public void SetIdTechnicien(string unid_technicien)
        {
            id_technicien = unid_technicien;
        }

        /// <summary>
        /// Obtient le niveau d'intervention du technicien.
        /// </summary>
        /// <returns>Le niveau d'intervention du technicien.</returns>
        public string GetNiveauIntervention()
        {
            return niveau_intervention;
        }

        /// <summary>
        /// Modifie le niveau d'intervention du technicien.
        /// </summary>
        /// <param name="unNiveauIntervention">Le nouveau niveau d'intervention.</param>
        public void SetNiveauIntervention(string unNiveauIntervention)
        {
            niveau_intervention = unNiveauIntervention;
        }

        /// <summary>
        /// Obtient la formation du technicien.
        /// </summary>
        /// <returns>La formation du technicien.</returns>
        public string GetFormation()
        {
            return formationT;
        }

        /// <summary>
        /// Modifie la formation du technicien.
        /// </summary>
        /// <param name="Uneformation">La nouvelle formation du technicien.</param>
        public void SetFormation(string Uneformation)
        {
            formationT = Uneformation;
        }

        /// <summary>
        /// Obtient le mot de passe du technicien.
        /// </summary>
        /// <returns>Le mot de passe du technicien.</returns>
        public string GetMdp()
        {
            return mdp;
        }

        /// <summary>
        /// Modifie le mot de passe du technicien.
        /// </summary>
        /// <param name="UnMdp">Le nouveau mot de passe du technicien.</param>
        public void SetMdp(string UnMdp)
        {
            mdp = UnMdp;
        }
    }
}
