﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente une compétence dans le système.
    /// </summary>
    public class Competence
    {
        private int id_competence;  // Identifiant unique de la compétence
        private string description; // Description de la compétence

        /// <summary>
        /// Constructeur de la classe Competence.
        /// Initialise une nouvelle compétence avec un identifiant et une description.
        /// </summary>
        /// <param name="id_competence">L'identifiant unique de la compétence.</param>
        /// <param name="description">La description de la compétence.</param>
        public Competence(int id_competence, string description)
        {
            this.id_competence = id_competence;  // Assigner l'identifiant de la compétence
            this.description = description;      // Assigner la description de la compétence
        }

        /// <summary>
        /// Constructeur de la classe Competence.
        /// Initialise une nouvelle compétence avec seulement une description.
        /// </summary>
        /// <param name="description">La description de la compétence.</param>
        public Competence(string description)
        {
            this.description = description;  // Assigner la description de la compétence
        }

        /// <summary>
        /// Obtient l'identifiant de la compétence.
        /// </summary>
        /// <returns>L'identifiant de la compétence.</returns>
        public int getId_competence()
        {
            return id_competence;
        }

        /// <summary>
        /// Obtient la description de la compétence.
        /// </summary>
        /// <returns>La description de la compétence.</returns>
        public string getDescription()
        {
            return description;
        }

        /// <summary>
        /// Modifie la description de la compétence.
        /// </summary>
        /// <param name="LaDescription">La nouvelle description de la compétence.</param>
        public void setDescription(string LaDescription)
        {
            description = LaDescription;  // Correction: assigner la nouvelle description à l'attribut 'description'
        }
    }
}
