﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente un personnel dans le système.
    /// </summary>
    public class Personnel
    {
        // Variables d'instance privées pour stocker les informations du personnel
        private string nomP;              // Nom du personnel
        private string matricule;         // Matricule du personnel
        private string identiteP;         // Identité du personnel
        private DateTime date_embauche;   // Date d'embauche du personnel
        private string region;            // Région du personnel
        private string id_personnel;      // Identifiant unique du personnel
        private Boolean responsable;      // Indicateur de responsabilité du personnel
        private string mdp;               // Mot de passe du personnel

        /// <summary>
        /// Constructeur pour initialiser un nouveau personnel avec des valeurs fournies.
        /// </summary>
        /// <param name="nomP">Nom du personnel.</param>
        /// <param name="matricule">Matricule du personnel.</param>
        /// <param name="identiteP">Identité du personnel (individuelle ou résidentielle).</param>
        /// <param name="date_embauche">Date d'embauche du personnel.</param>
        /// <param name="region">Région du personnel.</param>
        /// <param name="id_personnel">Identifiant unique du personnel.</param>
        /// <param name="responsable">Indicateur de responsabilité du personnel.</param>
        /// <param name="mdp">Mot de passe du personnel.</param>
        public Personnel(string nomP, string matricule, string identiteP, DateTime date_embauche, string region, string id_personnel, Boolean responsable, string mdp)
        {
            this.nomP = nomP;
            this.matricule = matricule;
            this.identiteP = identiteP;
            this.date_embauche = date_embauche;
            this.region = region;
            this.id_personnel = id_personnel;
            this.responsable = responsable;
            this.mdp = mdp;
        }

        /// <summary>
        /// Constructeur pour initialiser un nouveau personnel sans l'identifiant unique.
        /// </summary>
        /// <param name="nomP">Nom du personnel.</param>
        /// <param name="matricule">Matricule du personnel.</param>
        /// <param name="identiteP">Identité du personnel (individuelle ou résidentielle).</param>
        /// <param name="date_embauche">Date d'embauche du personnel.</param>
        /// <param name="region">Région du personnel.</param> 
        /// <param name="responsable">Indicateur de responsabilité du personnel.</param>
        /// <param name="mdp">Mot de passe du personnel.</param>
        public Personnel(string nomP, string matricule, string identiteP, DateTime date_embauche, string region, Boolean responsable, string mdp)
        {
            this.nomP = nomP;
            this.matricule = matricule;
            this.identiteP = identiteP;
            this.date_embauche = date_embauche;
            this.region = region;
            this.responsable = responsable;
            this.mdp = mdp;
        }

        /// <summary>
        /// Obtient le nom du personnel.
        /// </summary>
        /// <returns>Le nom du personnel.</returns>
        public string getNomP()
        {
            return nomP;
        }

        /// <summary>
        /// Obtient le matricule du personnel.
        /// </summary>
        /// <returns>Le matricule du personnel.</returns>
        public string getMatricule()
        {
            return matricule;
        }

        /// <summary>
        /// Obtient l'identité du personnel.
        /// </summary>
        /// <returns>L'identité du personnel.</returns>
        public string getIdentiteP()
        {
            return identiteP;
        }

        /// <summary>
        /// Obtient la date d'embauche du personnel.
        /// </summary>
        /// <returns>La date d'embauche du personnel.</returns>
        public DateTime getDte_embauche()
        {
            return date_embauche;
        }

        /// <summary>
        /// Obtient la région du personnel.
        /// </summary>
        /// <returns>La région du personnel.</returns>
        public string getRegion()
        {
            return region;
        }

        /// <summary>
        /// Obtient l'identifiant unique du personnel.
        /// </summary>
        /// <returns>L'identifiant du personnel.</returns>
        public string getId_personnel()
        {
            return id_personnel;
        }

        /// <summary>
        /// Obtient l'indicateur de responsabilité du personnel.
        /// </summary>
        /// <returns>True si le personnel est responsable, sinon false.</returns>
        public bool getResponsable()
        {
            return responsable;
        }
        
        public string Getmdp()
        {
            return mdp;
        }

        /// <summary>
        /// Modifie l'identité du personnel.
        /// </summary>
        /// <param name="uneidentite">Nouvelle identité à affecter.</param>
        public void setIdentite(string uneidentite)
        {
            if (uneidentite == "individuelle")
            {
                identiteP = uneidentite;
            }
            if (uneidentite == "residentielle")
            {
                identiteP = uneidentite;
            }
        }

        /// <summary>
        /// Modifie la région du personnel.
        /// </summary>
        /// <param name="uneregion">Nouvelle région à affecter.</param>
        public void setRegion(string uneregion)
        {
            region = uneregion; // Cette ligne doit modifier l'attribut `region`, pas la variable locale
        }

        /// <summary>
        /// Modifie la date d'embauche du personnel.
        /// </summary>
        /// <param name="unedate_embauche">Nouvelle date d'embauche à affecter.</param>
        public void setdateEmbauche(DateTime unedate_embauche)
        {
            date_embauche = unedate_embauche;
        }
    }
}
