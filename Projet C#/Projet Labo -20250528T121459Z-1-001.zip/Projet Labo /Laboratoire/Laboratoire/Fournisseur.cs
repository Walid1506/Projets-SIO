﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente un fournisseur dans le système.
    /// </summary>
    public class Fournisseur
    {
        private int id_fournisseur;       // Identifiant unique du fournisseur
        private string nom_fournisseur;   // Nom du fournisseur

        /// <summary>
        /// Constructeur de la classe Fournisseur.
        /// Initialise un fournisseur avec un identifiant et un nom.
        /// </summary>
        /// <param name="id_fournisseur">L'identifiant unique du fournisseur.</param>
        /// <param name="nom_fournisseur">Le nom du fournisseur.</param>
        public Fournisseur(int id_fournisseur, string nom_fournisseur)
        {
            this.id_fournisseur = id_fournisseur;  // Assigner l'identifiant du fournisseur
            this.nom_fournisseur = nom_fournisseur; // Assigner le nom du fournisseur
        }

        /// <summary>
        /// Constructeur de la classe Fournisseur.
        /// Initialise un fournisseur avec seulement un nom.
        /// </summary>
        /// <param name="nom_fournisseur">Le nom du fournisseur.</param>
        public Fournisseur(string nom_fournisseur)
        {
            this.nom_fournisseur = nom_fournisseur; // Assigner le nom du fournisseur
        }

        /// <summary>
        /// Obtient l'identifiant du fournisseur.
        /// </summary>
        /// <returns>L'identifiant unique du fournisseur.</returns>
        public int getId_fournisseur()
        {
            return id_fournisseur;  // Retourne l'identifiant du fournisseur
        }

        /// <summary>
        /// Obtient le nom du fournisseur.
        /// </summary>
        /// <returns>Le nom du fournisseur.</returns>
        public string getNomFournisseur()
        {
            return nom_fournisseur; // Retourne le nom du fournisseur
        }
    }
}
