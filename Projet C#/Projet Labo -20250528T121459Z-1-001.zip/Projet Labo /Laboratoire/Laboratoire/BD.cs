﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Laboratoire
{
    public class BD
    {
        /// <summary>
        /// Classe BD pour gérer les interactions avec la base de données `laboratoire`.
        /// </summary>
        private static string connStr = "Server=127.0.0.1; Database=laboratoire; Uid=root; Password=; ";
        MySqlConnection conn;
        /// <summary>
        /// Ouvre une connexion à la base de données et la retourne.
        /// </summary>
        /// <returns>Une connexion ouverte à la base de données.</returns>
        public static MySqlConnection Connexion()
        {
            MySqlConnection connection = new MySqlConnection(connStr);

            try
            {
                connection.Open();
                Console.WriteLine("Connexion à la base de données réussie.");
                return connection;
            }
            catch (MySqlException ex)
            {
                Console.WriteLine($"Erreur de connexion : {ex.Message}");
                throw new Exception("Impossible de se connecter à la base de données.", ex);
            }
        }
        /// <summary>
        /// Ferme la connexion à la base de données.
        /// </summary>
        public static void Deconnexion()
        {
            Connexion().Close();
        }



        public static bool VerifUserResponsable(string matricule, string mdp)
        {
            bool estResponsable = false;

            using (MySqlConnection connection = Connexion())
            {
               

                string requete = "SELECT responsable FROM Personnel WHERE matricule = @matricule AND mdp = @mdp";

                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@matricule", matricule);
                    commande.Parameters.AddWithValue("@mdp", mdp);

                    object result = commande.ExecuteScalar();  

                    if (result != null && result != DBNull.Value)
                    {
                        bool estResponsableBDD = Convert.ToBoolean(result); 
                        if (estResponsableBDD)
                        {
                            Console.WriteLine("L'utilisateur est bien un responsable.");
                            estResponsable = true;
                        }
                        else
                        {
                            Console.WriteLine("L'utilisateur existe mais N'EST PAS un responsable.");
                            estResponsable = false;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Matricule ou mot de passe incorrect.");
                    }
                }
            }

            return estResponsable;
        }



        public static void AddChercheur(Chercheurs unChercheur)
        {


            using (MySqlConnection connection = Connexion())
            {

                string requete = "INSERT INTO chercheurs ( prenom , nom , specialite, annee) VALUES ( @prenom , @nom, @specialite, @annee)";


                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {

                  
                    commande.Parameters.AddWithValue("@prenom", unChercheur.getPrenom());
                    commande.Parameters.AddWithValue("@nom", unChercheur.getNom());
                    commande.Parameters.AddWithValue("@specialite", unChercheur.getSpecialite());
                    commande.Parameters.AddWithValue("@annee", unChercheur.GetAnnee());


                    commande.ExecuteNonQuery();




                }
            }
            Connexion().Close();
        }




        /// <summary>
        /// Ajoute un technicien à la base de données.
        /// </summary>
        /// <param name="unTechnicien">Objet Technicien à ajouter.</param>




        public static void AddTechnicien(Technicien unTechnicien)
        {


            using (MySqlConnection connection = Connexion())
            {

                string requete = "INSERT INTO technicien (niveau_intervention, formation , mdp) VALUES (@niveau_technicien, @formationT , @mdp)";


                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {

                    commande.Parameters.AddWithValue("@niveau_technicien", unTechnicien.GetNiveauIntervention());
                    commande.Parameters.AddWithValue("@formationT", unTechnicien.GetFormation());
                    commande.Parameters.AddWithValue("@mdp", unTechnicien.GetMdp());


                    commande.ExecuteNonQuery();




                }
            }
            Connexion().Close();
        }




        public static List<Chercheurs> SelectChercheurs()
        {
            List<Chercheurs> lesChercheurs = new List<Chercheurs>();


            using (MySqlConnection connection = Connexion())
            {

                string requete = "SELECT * FROM chercheurs";


                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {

                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {

                        while (reader.Read())
                        {

                            Chercheurs unChercheur = new Chercheurs(
                                Convert.ToInt32(reader["id_chercheur"].ToString()),
                                reader["prenom"].ToString(),
                                reader["nom"].ToString(),
                                reader["specialite"].ToString(),
                                reader["annee"].ToString()
                            );


                            lesChercheurs.Add(unChercheur);
                        }
                    }
                }
            }

            return lesChercheurs;
        }
        /// <summary>
        /// Modifie les informations d'un technicien.
        /// </summary>
        /// <param name="id">ID du technicien à modifier.</param>
        /// <param name="formationT">Nouvelle formation du technicien.</param>
        public static void ModifTechnicien(int id, string formationT)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "UPDATE technicien SET  formation = @formation WHERE id_technicien = @id ";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id", id);
                    commande.Parameters.AddWithValue("@formation", formationT);
                    commande.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Supprime un technicien de la base de données.
        /// </summary>
        /// <param name="id">ID du technicien à supprimer.</param>
        public static void SuppTechnicien(int id)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "DELETE  FROM technicien WHERE id_technicien = @id_technicien";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_technicien", id);


                    commande.ExecuteNonQuery();
                }
            }
            Connexion().Close();
        }
        /// <summary>
        /// Sélectionne tous les techniciens dans la base de données.
        /// </summary>
        /// <returns>Liste de techniciens.</returns>






        public static List<Technicien> SelectTechnicien()
        {
            List<Technicien> lesTechniciens = new List<Technicien>();


            using (MySqlConnection connection = Connexion())
            {

                string requete = "SELECT * FROM technicien";


                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {

                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {

                        while (reader.Read())
                        {

                            Technicien unTechnicien = new Technicien(
                                reader["niveau_intervention"].ToString(),
                                reader["formation"].ToString()
                            );


                            lesTechniciens.Add(unTechnicien);
                        }
                    }
                }
            }

            return lesTechniciens;
        }
        /// <summary>
        /// Ajoute un ticket à la base de données.
        /// </summary>
        /// <param name="unTicket">Objet Ticket à ajouter.</param>




        public static void AddTicket(Ticket unTicket)
        {

            using (MySqlConnection connection = Connexion())
            {
                string requete = "INSERT INTO ticket (urgence,etat,type_demande,date_ticket,id_technicien,id_materiel,matricule,description) VALUES (@urgence,@etat,@type_demande,@date_ticket,@id_technicien,@id_materiel,@matricule,@description)";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@urgence", unTicket.GetUrgence());
                    commande.Parameters.AddWithValue("@etat", unTicket.GetEtat());
                    commande.Parameters.AddWithValue("@type_demande", unTicket.GetType());
                    commande.Parameters.AddWithValue("@date_ticket", unTicket.GetDateTicket());
                    commande.Parameters.AddWithValue("@id_technicien", unTicket.GetIdTechnicien());
                    commande.Parameters.AddWithValue("@id_materiel", unTicket.GetIdMateriel());
                    commande.Parameters.AddWithValue("@matricule", unTicket.GetMatricule());
                    commande.Parameters.AddWithValue("@descripton", unTicket.GetDescription());
                    commande.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Sélectionne tous les tickets dans la base de données.
        /// </summary>
        /// <returns>Liste de tickets.</returns>


        public static List<Ticket> SelectTicket()
        {
            List<Ticket> lesTickets = new List<Ticket>();

            using (MySqlConnection connection = Connexion())
            {
                string requete = "SELECT * FROM ticket";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Ticket unTicket = new Ticket(Convert.ToInt32((reader["id_ticket"])), reader["type_demande"].ToString(), reader["etat"].ToString(), reader["urgence"].ToString(), reader["date_ticket"].ToString(), Convert.ToInt32((reader["id_technicien"])), reader["id_materiel"].ToString(), reader["matricule"].ToString(), reader["description"].ToString());
                            lesTickets.Add(unTicket);
                        }
                    }
                }
            }

            return lesTickets;
        }
        /// <summary>
        /// Ajoute un matériel à la base de données.
        /// </summary>
        /// <param name="unMateriel">Objet Materiel à ajouter.</param>

        public static void AddMateriel(Materiel unMateriel)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "INSERT INTO materiel (type,memoire,processeur,logiciels_installes,date_achat,id_fournisseur) VALUES (@type,@memoire,@processeur,@logiciels_installes,@date_achat,@id_fournisseur)";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {

                    commande.Parameters.AddWithValue("@type", unMateriel.getleType());
                    commande.Parameters.AddWithValue("@memoire", unMateriel.getMemoire());
                    commande.Parameters.AddWithValue("@processeur", unMateriel.getProcesseur());
                    commande.Parameters.AddWithValue("@logiciels_installes", unMateriel.getLogiciel());
                    commande.Parameters.AddWithValue("@date_achat", unMateriel.getDate_achat());
                    commande.Parameters.AddWithValue("@id_fournisseur", unMateriel.getId_Fournisseur());
                    commande.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Sélectionne tous les matériels dans la base de données.
        /// </summary>
        /// <returns>Liste de matériels.</returns>
        public static List<Materiel> SelectMateriel()
        {
            List<Materiel> lesMateriels = new List<Materiel>();

            using (MySqlConnection connection = Connexion())
            {
                string requete = "SELECT * FROM materiel";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Materiel unMateriel = new Materiel(Convert.ToInt32((reader["id_materiel"])), reader["type"].ToString(), reader["memoire"].ToString(), reader["processeur"].ToString(), reader["logiciels_installes"].ToString(), reader["date_achat"].ToString(), Convert.ToInt32(reader["id_fournisseur"]));

                            lesMateriels.Add(unMateriel);
                        }
                    }
                }
            }

            return lesMateriels;
        }
        /// <summary>
        /// Supprime un matériel de la base de données en fonction de son ID.
        /// </summary>
        /// <param name="id">ID du matériel à supprimer.</param>
        public static void SuppMateriel(int id)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "DELETE  FROM materiel WHERE id_materiel = @id_materiel";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_materiel", id);


                    commande.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Ajoute une compétence à la base de données.
        /// </summary>
        /// <param name="uneCompetence">Objet Competence à ajouter.</param>



        public static void AddCompetence(Competence uneCompetence)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "INSERT INTO competence (id_competence,description) VALUES (@id_competence,@description)";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_competence", uneCompetence.getId_competence());
                    commande.Parameters.AddWithValue("@descrption", uneCompetence.getDescription());
                    commande.ExecuteNonQuery();
                }
            }
        }



        /// <summary>
        /// Sélectionne toutes les compétences dans la base de données.
        /// </summary>
        /// <returns>Liste de compétences.</returns>

        public static List<Competence> SelectCompetence()
        {
            List<Competence> lesCompetences = new List<Competence>();

            using (MySqlConnection connection = Connexion())
            {
                string requete = "SELECT description FROM competence";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Competence uneCompetence = new Competence(reader["description"].ToString());
                            lesCompetences.Add(uneCompetence);
                        }
                    }
                }
            }

            return lesCompetences;
        }

        /// <summary>
        /// Ajoute un fournisseur à la base de données.
        /// </summary>
        /// <param name="unFournisseur">Objet Fournisseur à ajouter.</param>
        public static void AddFournisseur(Fournisseur unFournisseur)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "INSERT INTO fournisseur (id_fournisseur,nom_fournisseur) VALUES (@id_fournisseur,@nom_fournisseur)";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_fournisseur", unFournisseur.getId_fournisseur());
                    commande.Parameters.AddWithValue("@nom_fournisseur", unFournisseur.getNomFournisseur());
                    commande.ExecuteNonQuery();
                }
            }
        }


        /// <summary>
        /// Sélectionne tous les fournisseurs dans la base de données.
        /// </summary>
        /// <returns>Liste de fournisseurs.</returns>
        public static List<Fournisseur> SelectFournisseur()
        {
            List<Fournisseur> lesFournisseurs = new List<Fournisseur>();

            using (MySqlConnection connection = Connexion())
            {
                string requete = "SELECT nom_fournisseur FROM fournisseur";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Fournisseur unFournisseur = new Fournisseur(reader["nom_fournisseur"].ToString());
                            lesFournisseurs.Add(unFournisseur);
                        }
                    }
                }
            }

            return lesFournisseurs;
        }


        /// <summary>
        /// Ajoute un personnel à la base de données.
        /// </summary>
        /// <param name="unPersonnel">Objet Personnel à ajouter.</param>
        public static void AddPersonnel(Personnel unPersonnel)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "INSERT INTO personnel (nomP,matricule,identite,date_embauche,region, id_personnel,responsable,mdp) VALUES (@nomP,@matricule,@identite,@date_embauche,@region,@id_personnel,@responsable, @mdp)";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@identite", unPersonnel.getIdentiteP());
                    commande.Parameters.AddWithValue("@matricule", unPersonnel.getMatricule());
                    commande.Parameters.AddWithValue("@nomP", unPersonnel.getNomP());
                    commande.Parameters.AddWithValue("@date_embauche", unPersonnel.getDte_embauche());
                    commande.Parameters.AddWithValue("@region", unPersonnel.getRegion());
                    commande.Parameters.AddWithValue("@id_personnel", unPersonnel.getId_personnel());
                    commande.Parameters.AddWithValue("@responsable", unPersonnel.getResponsable());
                    commande.Parameters.AddWithValue("@mdp", unPersonnel.Getmdp());
                    commande.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Modifie les informations d'un personnel.
        /// </summary>
        /// <param name="id">ID du personnel à modifier.</param>
        /// <param name="identiteP">Nouvelle identité du personnel.</param>

        public static void ModifPersonnel(int id, string identiteP)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "UPDATE personnel SET  identite= @identite WHERE id_personnel = @id_personnel";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_personnel", id);
                    commande.Parameters.AddWithValue("@identite", identiteP);

                    commande.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Supprime un personnel de la base de données en fonction de son ID.
        /// </summary>
        /// <param name="id">ID du personnel à supprimer.</param>

        public static void SuppPersonnel(int id)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "DELETE  FROM personnel WHERE id_personnel = @id_personnel";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@id_personnel", id);


                    commande.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Sélectionne tous les personnels dans la base de données.
        /// </summary>
        /// <returns>Liste de personnels.</returns>

        public static List<Personnel> SelectPersonnel()
        {
            List<Personnel> lesPersonnels = new List<Personnel>();

            using (MySqlConnection connection = Connexion())
            {
                string requete = "SELECT nomP FROM personnel";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    using (MySqlDataReader reader = commande.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Personnel unPersonnel = new Personnel(reader["identiteP"].ToString(), reader["matricule"].ToString(), reader["nomP"].ToString(), Convert.ToDateTime((reader["date_embauche"])), reader["region"].ToString(), Convert.ToBoolean(reader["responsable"]), reader["mdp"].ToString());
                            lesPersonnels.Add(unPersonnel);
                        }
                    }
                }
            }

            return lesPersonnels;
        }
        /// <summary>
        /// Modifie l'état et la description d'un ticket.
        /// </summary>
        /// <param name="idT">ID du ticket à modifier.</param>
        /// <param name="etat">Nouvel état du ticket.</param>
        /// <param name="Description">Nouvelle description du ticket.</param>
        public static void ModifTicket(int idT, string etat, string Description)
        {
            using (MySqlConnection connection = Connexion())
            {
                string requete = "UPDATE ticket SET  etat = @etat, Description = @Description WHERE id_ticket = @id_ticket ";
                using (MySqlCommand commande = new MySqlCommand(requete, connection))
                {
                    commande.Parameters.AddWithValue("@etat", etat);
                    commande.Parameters.AddWithValue("@Description", Description);
                    commande.Parameters.AddWithValue("@id_ticket", idT);
                    commande.ExecuteNonQuery();
                }
            }
        }
    }
    }

