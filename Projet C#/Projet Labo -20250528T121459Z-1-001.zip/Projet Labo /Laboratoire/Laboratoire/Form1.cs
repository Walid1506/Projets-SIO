﻿ using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql;

namespace Laboratoire
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="Form1"/>.
        /// Configure les onglets visibles au démarrage de l'application.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);

        }


        /// <summary>
        /// Gère l'événement de clic sur le bouton de connexion.
        /// Active ou désactive les onglets en fonction du rôle saisi.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonConnexion_Click(object sender, EventArgs e)
        {

            
            bool IsRes = BD.VerifUserResponsable(textBox1.Text , textBox2.Text);

            if (IsRes == true)
            {
                tabControl1.TabPages.Add(tabPage5);
                tabControl1.TabPages.Add(tabPage2);
                tabControl1.TabPages.Add(tabPage3);
                tabControl1.TabPages.Add(tabPage4);
                tabControl1.TabPages.Remove(tabPage1);


            }
            else
            {
                tabControl1.TabPages.Remove(tabPage1);
                tabControl1.TabPages.Add(tabPage2);
                tabControl1.TabPages.Add(tabPage3);


            }
        }
        /// <summary>
        /// Ajoute un nouveau matériel à la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonAjoutMateriel_Click(object sender, EventArgs e)
        {
            Materiel unMateriel = new Materiel(Convert.ToString(textBoxType.Text), Convert.ToString(textBoxMemoire.Text), Convert.ToString(textBoxProcesseur.Text), Convert.ToString(textBoxLogiciel.Text), textBoxDateAchat.Text, Convert.ToInt32(textBoxFourniseur.Text));

            BD.AddMateriel(unMateriel);


        }
        /// <summary>
        /// Supprime un matériel en fonction de son ID.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonSupprimerMateriel_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxsuppMat.Text);
            BD.SuppMateriel(id);

        }
        /// <summary>
        /// Ajoute un nouveau technicien à la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonAjoutTechnicien_Click(object sender, EventArgs e)
        {
            Technicien unTechnicien = new Technicien(Convert.ToString(textBoxNvInter.Text), Convert.ToString(textBoxFormation.Text), Convert.ToString(textBoxMdpT.Text));
            BD.AddTechnicien(unTechnicien);
        }
        /// <summary>
        /// Ajoute un nouvel utilisateur à la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonAjoutUtilisateur_Click(object sender, EventArgs e)
        {
            Personnel unPersonnel = new Personnel(Convert.ToString(textBoxNomP.Text), Convert.ToString(textBoxMatricule.Text), Convert.ToString(textBoxidentite.Text), Convert.ToDateTime(textBoxDateEmbauche.Text), textBoxRegion.Text, checkBoxResponsable.Checked, Convert.ToString(textBoxMdpU.Text));
            BD.AddPersonnel(unPersonnel);



        }
        /// <summary>
        /// Supprime un technicien en fonction de son ID.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonSuppTech_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxIDTsupp.Text);
            BD.SuppTechnicien(id);

        }
        /// <summary>
        /// Supprime un utilisateur en fonction de son ID.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonSuppPersonnel_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxIDPSupp.Text);
            BD.SuppPersonnel(id);

        }
        /// <summary>
        /// Modifie les informations d'un technicien dans la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonModifierTech_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxIdModifT.Text);
            string formation = textBoxModifFormT.Text;
            BD.ModifTechnicien(id, formation);
        }
        /// <summary>
        /// Modifie les informations d'un utilisateur dans la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonModifierUtilisateur_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBoxIdmodifU.Text);
            string identite = textBoxModifUtili.Text;
            BD.ModifPersonnel(id, identite);

        }
        /// <summary>
        /// Affiche tous les matériels dans la liste.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonAfficherMateriel_Click(object sender, EventArgs e)
        {
 listBoxMateriel.Items.Clear();

            foreach (Materiel unMateriel in BD.SelectMateriel())
            {
               
                listBoxMateriel.Items.Add(Convert.ToString((unMateriel.getId_materiel() + " " + unMateriel.getleType())));
            }

        }
        /// <summary>
        /// Affiche tous les incidents dans la liste.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>
        private void buttonConsulterIncidents_Click(object sender, EventArgs e)
        {  listBoxIncidents.Items.Clear();
            foreach (Ticket unTicket in BD.SelectTicket())
            {
              
                listBoxIncidents.Items.Add(Convert.ToString((unTicket.GetIdTicket() + " " + unTicket.GetEtat()+" " + unTicket.GetTypeDemande() + " " + unTicket.GetUrgence())));
            }

        }
       
    
        /// <summary>
        /// Déclare un nouveau ticket dans la base de données.
        /// </summary>
        /// <param name="sender">Objet qui déclenche l'événement.</param>
        /// <param name="e">Données associées à l'événement.</param>

        private void buttonModifierEtat_Click(object sender, EventArgs e)
        {
            int idT = Convert.ToInt32(textBoxIdT.Text);
            string etat = Convert.ToString(textBoxEtat.Text);
            string Description = Convert.ToString(textBoxTravailE.Text);
            BD.ModifTicket (idT,etat, Description);

        }

        private void buttonDeclarer_Click(object sender, EventArgs e)
        {
            Ticket unTicket = new Ticket(textBoxUrgence.Text, textBoxEtat1.Text, textBoxTypeD.Text, textBoxDate1.Text);
            BD.AddTicket(unTicket);
        }

        private void AjoutCh_Click(object sender, EventArgs e)
        {
            Chercheurs unChercheur = new Chercheurs(Convert.ToString(PrenomChercheur.Text), Convert.ToString(NomChercheur.Text), Convert.ToString(specialite.Text), Convert.ToString(Annee.Text));

            BD.AddChercheur(unChercheur);

        }


        private void BtCh_Click(object sender, EventArgs e)
        {
            listBoxCh.Items.Clear();
            foreach (Chercheurs unChercheur in BD.SelectChercheurs())
            {

                listBoxCh.Items.Add(unChercheur.getId_chercheur() + " " + unChercheur.getPrenom() + " " + unChercheur.getNom() + " " + unChercheur.getSpecialite() + " " + unChercheur.GetAnnee());
            }

        }

      
    }
    }


