﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratoire
{
    /// <summary>
    /// Représente un matériel dans le système.
    /// </summary>
    public class Materiel
    {
        // Variables d'instance privées pour stocker les attributs du matériel
        private int id_materiel;         // Identifiant unique du matériel
        private string letype;           // Type de matériel
        private string memoire;          // Mémoire du matériel
        private string processeur;       // Processeur du matériel
        private string logiciel;         // Logiciel installé sur le matériel
        private string date_achat;       // Date d'achat du matériel
        private int id_fournisseur;      // Identifiant du fournisseur du matériel

        /// <summary>
        /// Constructeur de la classe Materiel.
        /// Initialise un nouveau matériel avec les valeurs fournies.
        /// </summary>
        /// <param name="id_materiel">L'identifiant du matériel.</param>
        /// <param name="letype">Le type du matériel.</param>
        /// <param name="memoire">La mémoire du matériel.</param>
        /// <param name="processeur">Le processeur du matériel.</param>
        /// <param name="logiciel">Le logiciel installé sur le matériel.</param>
        /// <param name="date_achat">La date d'achat du matériel.</param>
        /// <param name="id_fournisseur">L'identifiant du fournisseur.</param>
        public Materiel(int id_materiel, string letype, string memoire, string processeur, string logiciel, string date_achat, int id_fournisseur)
        {
            this.id_materiel = id_materiel;         // Assigner l'ID du matériel
            this.letype = letype;                   // Assigner le type du matériel
            this.memoire = memoire;                 // Assigner la mémoire
            this.processeur = processeur;           // Assigner le processeur
            this.logiciel = logiciel;               // Assigner le logiciel
            this.date_achat = date_achat;           // Assigner la date d'achat
            this.id_fournisseur = id_fournisseur;   // Assigner l'ID du fournisseur
        }

        /// <summary>
        /// Constructeur de la classe Materiel.
        /// Initialise un matériel avec les valeurs nécessaires sauf l'identifiant.
        /// </summary>
        /// <param name="letype">Le type du matériel.</param>
        /// <param name="memoire">La mémoire du matériel.</param>
        /// <param name="processeur">Le processeur du matériel.</param>
        /// <param name="logiciel">Le logiciel installé sur le matériel.</param>
        /// <param name="date_achat">La date d'achat du matériel.</param>
        /// <param name="id_fournisseur">L'identifiant du fournisseur.</param>
        public Materiel(string letype, string memoire, string processeur, string logiciel, string date_achat, int id_fournisseur)
        {
            this.letype = letype;                   // Assigner le type du matériel
            this.memoire = memoire;                 // Assigner la mémoire
            this.processeur = processeur;           // Assigner le processeur
            this.logiciel = logiciel;               // Assigner le logiciel
            this.date_achat = date_achat;           // Assigner la date d'achat
            this.id_fournisseur = id_fournisseur;   // Assigner l'ID du fournisseur
        }

        /// <summary>
        /// Obtient l'identifiant du matériel.
        /// </summary>
        /// <returns>L'identifiant du matériel.</returns>
        public int getId_materiel()
        {
            return id_materiel;
        }

        /// <summary>
        /// Obtient le type du matériel.
        /// </summary>
        /// <returns>Le type du matériel.</returns>
        public string getleType()
        {
            return letype;
        }

        /// <summary>
        /// Obtient la mémoire du matériel.
        /// </summary>
        /// <returns>La mémoire du matériel.</returns>
        public string getMemoire()
        {
            return memoire;
        }

        /// <summary>
        /// Obtient le processeur du matériel.
        /// </summary>
        /// <returns>Le processeur du matériel.</returns>
        public string getProcesseur()
        {
            return processeur;
        }

        /// <summary>
        /// Obtient le logiciel installé sur le matériel.
        /// </summary>
        /// <returns>Le logiciel installé sur le matériel.</returns>
        public string getLogiciel()
        {
            return logiciel;
        }

        /// <summary>
        /// Obtient la date d'achat du matériel.
        /// </summary>
        /// <returns>La date d'achat du matériel.</returns>
        public string getDate_achat()
        {
            return date_achat;
        }

        /// <summary>
        /// Obtient l'identifiant du fournisseur du matériel.
        /// </summary>
        /// <returns>L'identifiant du fournisseur.</returns>
        public int getId_Fournisseur()
        {
            return id_fournisseur;
        }

        /// <summary>
        /// Modifie le type du matériel en fonction de certaines conditions.
        /// </summary>
        /// <param name="letype">Le nouveau type du matériel.</param>
        public void setleType(string letype)
        {
            // Vérifie si le type fourni correspond à l'une des valeurs spécifiques et le modifie en conséquence
            if (letype == "Prise en charge par telephone")
            {
                this.letype = letype;
            }
            if (letype == "Prise en charge en télémaintenance")
            {
                this.letype = letype;
            }
            if (letype == "Prise en charge en télémaintenance")
            {
                this.letype = letype;
            }
        }

        /// <summary>
        /// Modifie le logiciel installé sur le matériel.
        /// </summary>
        /// <param name="lelogiciel">Le nouveau logiciel à installer sur le matériel.</param>
        public void setLogiciel(string lelogiciel)
        {
            lelogiciel = logiciel; // Note: Cette ligne semble incorrecte, elle affecte la variable locale `lelogiciel` et non l'attribut `logiciel`
        }
    }
}
