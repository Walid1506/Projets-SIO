﻿namespace Laboratoire
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.buttonConnexion = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxFourniseur = new System.Windows.Forms.TextBox();
            this.buttonAfficherMateriel = new System.Windows.Forms.Button();
            this.listBoxMateriel = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxsuppMat = new System.Windows.Forms.TextBox();
            this.buttonSupprimerMateriel = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxDateAchat = new System.Windows.Forms.TextBox();
            this.textBoxProcesseur = new System.Windows.Forms.TextBox();
            this.textBoxLogiciel = new System.Windows.Forms.TextBox();
            this.textBoxMemoire = new System.Windows.Forms.TextBox();
            this.textBoxType = new System.Windows.Forms.TextBox();
            this.buttonAjoutMateriel = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.buttonDeclarer = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.textBoxDate1 = new System.Windows.Forms.TextBox();
            this.textBoxTypeD = new System.Windows.Forms.TextBox();
            this.textBoxEtat1 = new System.Windows.Forms.TextBox();
            this.textBoxUrgence = new System.Windows.Forms.TextBox();
            this.listBoxIncidents = new System.Windows.Forms.ListBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxIdT = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxTravailE = new System.Windows.Forms.TextBox();
            this.textBoxEtat = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonModifierEtat = new System.Windows.Forms.Button();
            this.buttonConsulterIncidents = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label26 = new System.Windows.Forms.Label();
            this.textBoxRegion = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBoxIdmodifU = new System.Windows.Forms.TextBox();
            this.textBoxIdModifT = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxModifUtili = new System.Windows.Forms.TextBox();
            this.buttonModifierUtilisateur = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxModifFormT = new System.Windows.Forms.TextBox();
            this.buttonModifierTech = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxIDPSupp = new System.Windows.Forms.TextBox();
            this.buttonSuppPersonnel = new System.Windows.Forms.Button();
            this.Id = new System.Windows.Forms.Label();
            this.textBoxIDTsupp = new System.Windows.Forms.TextBox();
            this.buttonSuppTech = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxMdpU = new System.Windows.Forms.TextBox();
            this.checkBoxResponsable = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBoxMdpT = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxDateEmbauche = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxNomP = new System.Windows.Forms.TextBox();
            this.textBoxidentite = new System.Windows.Forms.TextBox();
            this.textBoxMatricule = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxNvInter = new System.Windows.Forms.TextBox();
            this.textBoxFormation = new System.Windows.Forms.TextBox();
            this.buttonAjoutUtilisateur = new System.Windows.Forms.Button();
            this.buttonAjoutTechnicien = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.BtCh = new System.Windows.Forms.Button();
            this.listBoxCh = new System.Windows.Forms.ListBox();
            this.AjoutCh = new System.Windows.Forms.Button();
            this.label37 = new System.Windows.Forms.Label();
            this.Annee = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.specialite = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.PrenomChercheur = new System.Windows.Forms.TextBox();
            this.NomChercheur = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1620, 594);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.buttonConnexion);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1612, 568);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Connexion";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // buttonConnexion
            // 
            this.buttonConnexion.Location = new System.Drawing.Point(549, 339);
            this.buttonConnexion.Name = "buttonConnexion";
            this.buttonConnexion.Size = new System.Drawing.Size(75, 23);
            this.buttonConnexion.TabIndex = 7;
            this.buttonConnexion.Text = "Connexion";
            this.buttonConnexion.UseVisualStyleBackColor = true;
            this.buttonConnexion.Click += new System.EventHandler(this.buttonConnexion_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(546, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Utilisateurs";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(481, 285);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mdp";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(481, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Login";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(537, 278);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(537, 222);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.textBoxFourniseur);
            this.tabPage2.Controls.Add(this.buttonAfficherMateriel);
            this.tabPage2.Controls.Add(this.listBoxMateriel);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.textBoxsuppMat);
            this.tabPage2.Controls.Add(this.buttonSupprimerMateriel);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.textBoxDateAchat);
            this.tabPage2.Controls.Add(this.textBoxProcesseur);
            this.tabPage2.Controls.Add(this.textBoxLogiciel);
            this.tabPage2.Controls.Add(this.textBoxMemoire);
            this.tabPage2.Controls.Add(this.textBoxType);
            this.tabPage2.Controls.Add(this.buttonAjoutMateriel);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1612, 568);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Materiel";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(91, 251);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Id Fournisseur";
            // 
            // textBoxFourniseur
            // 
            this.textBoxFourniseur.Location = new System.Drawing.Point(162, 244);
            this.textBoxFourniseur.Name = "textBoxFourniseur";
            this.textBoxFourniseur.Size = new System.Drawing.Size(100, 20);
            this.textBoxFourniseur.TabIndex = 19;
            // 
            // buttonAfficherMateriel
            // 
            this.buttonAfficherMateriel.Location = new System.Drawing.Point(529, 409);
            this.buttonAfficherMateriel.Name = "buttonAfficherMateriel";
            this.buttonAfficherMateriel.Size = new System.Drawing.Size(126, 30);
            this.buttonAfficherMateriel.TabIndex = 18;
            this.buttonAfficherMateriel.Text = "Afficher Materiel";
            this.buttonAfficherMateriel.UseVisualStyleBackColor = true;
            this.buttonAfficherMateriel.Click += new System.EventHandler(this.buttonAfficherMateriel_Click);
            // 
            // listBoxMateriel
            // 
            this.listBoxMateriel.FormattingEnabled = true;
            this.listBoxMateriel.Location = new System.Drawing.Point(444, 190);
            this.listBoxMateriel.Name = "listBoxMateriel";
            this.listBoxMateriel.Size = new System.Drawing.Size(297, 199);
            this.listBoxMateriel.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(441, 66);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "id_matériel";
            // 
            // textBoxsuppMat
            // 
            this.textBoxsuppMat.Location = new System.Drawing.Point(519, 66);
            this.textBoxsuppMat.Name = "textBoxsuppMat";
            this.textBoxsuppMat.Size = new System.Drawing.Size(100, 20);
            this.textBoxsuppMat.TabIndex = 15;
            // 
            // buttonSupprimerMateriel
            // 
            this.buttonSupprimerMateriel.Location = new System.Drawing.Point(499, 112);
            this.buttonSupprimerMateriel.Name = "buttonSupprimerMateriel";
            this.buttonSupprimerMateriel.Size = new System.Drawing.Size(126, 30);
            this.buttonSupprimerMateriel.TabIndex = 14;
            this.buttonSupprimerMateriel.Text = "Supprimer Materiel";
            this.buttonSupprimerMateriel.UseVisualStyleBackColor = true;
            this.buttonSupprimerMateriel.Click += new System.EventHandler(this.buttonSupprimerMateriel_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Mémoire";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(196, 190);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "Date Achat";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(183, 125);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Logiciel Installé";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(82, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Processeur";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 121);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Type";
            // 
            // textBoxDateAchat
            // 
            this.textBoxDateAchat.Location = new System.Drawing.Point(263, 183);
            this.textBoxDateAchat.Name = "textBoxDateAchat";
            this.textBoxDateAchat.Size = new System.Drawing.Size(100, 20);
            this.textBoxDateAchat.TabIndex = 8;
            // 
            // textBoxProcesseur
            // 
            this.textBoxProcesseur.Location = new System.Drawing.Point(148, 59);
            this.textBoxProcesseur.Name = "textBoxProcesseur";
            this.textBoxProcesseur.Size = new System.Drawing.Size(100, 20);
            this.textBoxProcesseur.TabIndex = 7;
            // 
            // textBoxLogiciel
            // 
            this.textBoxLogiciel.Location = new System.Drawing.Point(268, 118);
            this.textBoxLogiciel.Name = "textBoxLogiciel";
            this.textBoxLogiciel.Size = new System.Drawing.Size(100, 20);
            this.textBoxLogiciel.TabIndex = 6;
            // 
            // textBoxMemoire
            // 
            this.textBoxMemoire.Location = new System.Drawing.Point(77, 183);
            this.textBoxMemoire.Name = "textBoxMemoire";
            this.textBoxMemoire.Size = new System.Drawing.Size(100, 20);
            this.textBoxMemoire.TabIndex = 3;
            // 
            // textBoxType
            // 
            this.textBoxType.Location = new System.Drawing.Point(77, 118);
            this.textBoxType.Name = "textBoxType";
            this.textBoxType.Size = new System.Drawing.Size(100, 20);
            this.textBoxType.TabIndex = 1;
            // 
            // buttonAjoutMateriel
            // 
            this.buttonAjoutMateriel.Location = new System.Drawing.Point(148, 299);
            this.buttonAjoutMateriel.Name = "buttonAjoutMateriel";
            this.buttonAjoutMateriel.Size = new System.Drawing.Size(126, 30);
            this.buttonAjoutMateriel.TabIndex = 0;
            this.buttonAjoutMateriel.Text = "Ajout Materiel";
            this.buttonAjoutMateriel.UseVisualStyleBackColor = true;
            this.buttonAjoutMateriel.Click += new System.EventHandler(this.buttonAjoutMateriel_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.buttonDeclarer);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.label27);
            this.tabPage3.Controls.Add(this.textBoxDate1);
            this.tabPage3.Controls.Add(this.textBoxTypeD);
            this.tabPage3.Controls.Add(this.textBoxEtat1);
            this.tabPage3.Controls.Add(this.textBoxUrgence);
            this.tabPage3.Controls.Add(this.listBoxIncidents);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.textBoxIdT);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.textBoxTravailE);
            this.tabPage3.Controls.Add(this.textBoxEtat);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.buttonModifierEtat);
            this.tabPage3.Controls.Add(this.buttonConsulterIncidents);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1612, 568);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Incidents";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // buttonDeclarer
            // 
            this.buttonDeclarer.Location = new System.Drawing.Point(87, 499);
            this.buttonDeclarer.Name = "buttonDeclarer";
            this.buttonDeclarer.Size = new System.Drawing.Size(126, 30);
            this.buttonDeclarer.TabIndex = 39;
            this.buttonDeclarer.Text = "Déclarer incident";
            this.buttonDeclarer.UseVisualStyleBackColor = true;
            this.buttonDeclarer.Click += new System.EventHandler(this.buttonDeclarer_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(55, 452);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(30, 13);
            this.label31.TabIndex = 38;
            this.label31.Text = "Date";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(3, 402);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(81, 13);
            this.label30.TabIndex = 37;
            this.label30.Text = "Type_demande";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(55, 357);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(25, 13);
            this.label29.TabIndex = 36;
            this.label29.Text = "etat";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(43, 313);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 13);
            this.label27.TabIndex = 35;
            this.label27.Text = "Urgence";
            // 
            // textBoxDate1
            // 
            this.textBoxDate1.Location = new System.Drawing.Point(97, 445);
            this.textBoxDate1.Name = "textBoxDate1";
            this.textBoxDate1.Size = new System.Drawing.Size(126, 20);
            this.textBoxDate1.TabIndex = 34;
            // 
            // textBoxTypeD
            // 
            this.textBoxTypeD.Location = new System.Drawing.Point(97, 395);
            this.textBoxTypeD.Name = "textBoxTypeD";
            this.textBoxTypeD.Size = new System.Drawing.Size(126, 20);
            this.textBoxTypeD.TabIndex = 33;
            // 
            // textBoxEtat1
            // 
            this.textBoxEtat1.Location = new System.Drawing.Point(97, 350);
            this.textBoxEtat1.Name = "textBoxEtat1";
            this.textBoxEtat1.Size = new System.Drawing.Size(126, 20);
            this.textBoxEtat1.TabIndex = 32;
            // 
            // textBoxUrgence
            // 
            this.textBoxUrgence.Location = new System.Drawing.Point(97, 310);
            this.textBoxUrgence.Name = "textBoxUrgence";
            this.textBoxUrgence.Size = new System.Drawing.Size(126, 20);
            this.textBoxUrgence.TabIndex = 31;
            // 
            // listBoxIncidents
            // 
            this.listBoxIncidents.FormattingEnabled = true;
            this.listBoxIncidents.Location = new System.Drawing.Point(15, 54);
            this.listBoxIncidents.Name = "listBoxIncidents";
            this.listBoxIncidents.Size = new System.Drawing.Size(262, 173);
            this.listBoxIncidents.TabIndex = 30;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(494, 31);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(18, 13);
            this.label28.TabIndex = 29;
            this.label28.Text = "ID";
            // 
            // textBoxIdT
            // 
            this.textBoxIdT.Location = new System.Drawing.Point(526, 24);
            this.textBoxIdT.Name = "textBoxIdT";
            this.textBoxIdT.Size = new System.Drawing.Size(126, 20);
            this.textBoxIdT.TabIndex = 27;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(439, 100);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(81, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Travail effectué";
            // 
            // textBoxTravailE
            // 
            this.textBoxTravailE.Location = new System.Drawing.Point(526, 97);
            this.textBoxTravailE.Name = "textBoxTravailE";
            this.textBoxTravailE.Size = new System.Drawing.Size(126, 20);
            this.textBoxTravailE.TabIndex = 25;
            // 
            // textBoxEtat
            // 
            this.textBoxEtat.Location = new System.Drawing.Point(526, 54);
            this.textBoxEtat.Name = "textBoxEtat";
            this.textBoxEtat.Size = new System.Drawing.Size(126, 20);
            this.textBoxEtat.TabIndex = 24;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(494, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Etat";
            // 
            // buttonModifierEtat
            // 
            this.buttonModifierEtat.Location = new System.Drawing.Point(526, 142);
            this.buttonModifierEtat.Name = "buttonModifierEtat";
            this.buttonModifierEtat.Size = new System.Drawing.Size(126, 30);
            this.buttonModifierEtat.TabIndex = 22;
            this.buttonModifierEtat.Text = "Modifier Etat";
            this.buttonModifierEtat.UseVisualStyleBackColor = true;
            this.buttonModifierEtat.Click += new System.EventHandler(this.buttonModifierEtat_Click);
            // 
            // buttonConsulterIncidents
            // 
            this.buttonConsulterIncidents.Location = new System.Drawing.Point(75, 252);
            this.buttonConsulterIncidents.Name = "buttonConsulterIncidents";
            this.buttonConsulterIncidents.Size = new System.Drawing.Size(126, 30);
            this.buttonConsulterIncidents.TabIndex = 19;
            this.buttonConsulterIncidents.Text = "Consulter Incidents";
            this.buttonConsulterIncidents.UseVisualStyleBackColor = true;
            this.buttonConsulterIncidents.Click += new System.EventHandler(this.buttonConsulterIncidents_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.textBoxRegion);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.textBoxIdmodifU);
            this.tabPage4.Controls.Add(this.textBoxIdModifT);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.textBoxModifUtili);
            this.tabPage4.Controls.Add(this.buttonModifierUtilisateur);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.textBoxModifFormT);
            this.tabPage4.Controls.Add(this.buttonModifierTech);
            this.tabPage4.Controls.Add(this.label21);
            this.tabPage4.Controls.Add(this.textBoxIDPSupp);
            this.tabPage4.Controls.Add(this.buttonSuppPersonnel);
            this.tabPage4.Controls.Add(this.Id);
            this.tabPage4.Controls.Add(this.textBoxIDTsupp);
            this.tabPage4.Controls.Add(this.buttonSuppTech);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.textBoxMdpU);
            this.tabPage4.Controls.Add(this.checkBoxResponsable);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.textBoxMdpT);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.textBoxDateEmbauche);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.label16);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.textBoxNomP);
            this.tabPage4.Controls.Add(this.textBoxidentite);
            this.tabPage4.Controls.Add(this.textBoxMatricule);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.textBoxNvInter);
            this.tabPage4.Controls.Add(this.textBoxFormation);
            this.tabPage4.Controls.Add(this.buttonAjoutUtilisateur);
            this.tabPage4.Controls.Add(this.buttonAjoutTechnicien);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1612, 568);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Ajout/Modif";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(455, 37);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 13);
            this.label26.TabIndex = 38;
            this.label26.Text = "Region";
            // 
            // textBoxRegion
            // 
            this.textBoxRegion.Location = new System.Drawing.Point(509, 34);
            this.textBoxRegion.Name = "textBoxRegion";
            this.textBoxRegion.Size = new System.Drawing.Size(100, 20);
            this.textBoxRegion.TabIndex = 37;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(60, 332);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(15, 13);
            this.label25.TabIndex = 36;
            this.label25.Text = "id";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(286, 332);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(15, 13);
            this.label24.TabIndex = 35;
            this.label24.Text = "id";
            // 
            // textBoxIdmodifU
            // 
            this.textBoxIdmodifU.Location = new System.Drawing.Point(316, 325);
            this.textBoxIdmodifU.Name = "textBoxIdmodifU";
            this.textBoxIdmodifU.Size = new System.Drawing.Size(100, 20);
            this.textBoxIdmodifU.TabIndex = 34;
            // 
            // textBoxIdModifT
            // 
            this.textBoxIdModifT.Location = new System.Drawing.Point(87, 325);
            this.textBoxIdModifT.Name = "textBoxIdModifT";
            this.textBoxIdModifT.Size = new System.Drawing.Size(100, 20);
            this.textBoxIdModifT.TabIndex = 33;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(269, 373);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(41, 13);
            this.label23.TabIndex = 32;
            this.label23.Text = "identite";
            // 
            // textBoxModifUtili
            // 
            this.textBoxModifUtili.Location = new System.Drawing.Point(316, 366);
            this.textBoxModifUtili.Name = "textBoxModifUtili";
            this.textBoxModifUtili.Size = new System.Drawing.Size(100, 20);
            this.textBoxModifUtili.TabIndex = 31;
            // 
            // buttonModifierUtilisateur
            // 
            this.buttonModifierUtilisateur.Location = new System.Drawing.Point(304, 408);
            this.buttonModifierUtilisateur.Name = "buttonModifierUtilisateur";
            this.buttonModifierUtilisateur.Size = new System.Drawing.Size(124, 26);
            this.buttonModifierUtilisateur.TabIndex = 30;
            this.buttonModifierUtilisateur.Text = "Modifier Personnel";
            this.buttonModifierUtilisateur.UseVisualStyleBackColor = true;
            this.buttonModifierUtilisateur.Click += new System.EventHandler(this.buttonModifierUtilisateur_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(28, 366);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 29;
            this.label22.Text = "Formation";
            // 
            // textBoxModifFormT
            // 
            this.textBoxModifFormT.Location = new System.Drawing.Point(87, 363);
            this.textBoxModifFormT.Name = "textBoxModifFormT";
            this.textBoxModifFormT.Size = new System.Drawing.Size(100, 20);
            this.textBoxModifFormT.TabIndex = 28;
            // 
            // buttonModifierTech
            // 
            this.buttonModifierTech.Location = new System.Drawing.Point(63, 408);
            this.buttonModifierTech.Name = "buttonModifierTech";
            this.buttonModifierTech.Size = new System.Drawing.Size(124, 26);
            this.buttonModifierTech.TabIndex = 27;
            this.buttonModifierTech.Text = "Modifier Technicien";
            this.buttonModifierTech.UseVisualStyleBackColor = true;
            this.buttonModifierTech.Click += new System.EventHandler(this.buttonModifierTech_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(979, 88);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(15, 13);
            this.label21.TabIndex = 26;
            this.label21.Text = "id";
            // 
            // textBoxIDPSupp
            // 
            this.textBoxIDPSupp.Location = new System.Drawing.Point(1006, 81);
            this.textBoxIDPSupp.Name = "textBoxIDPSupp";
            this.textBoxIDPSupp.Size = new System.Drawing.Size(100, 20);
            this.textBoxIDPSupp.TabIndex = 25;
            // 
            // buttonSuppPersonnel
            // 
            this.buttonSuppPersonnel.CausesValidation = false;
            this.buttonSuppPersonnel.Location = new System.Drawing.Point(982, 132);
            this.buttonSuppPersonnel.Name = "buttonSuppPersonnel";
            this.buttonSuppPersonnel.Size = new System.Drawing.Size(124, 23);
            this.buttonSuppPersonnel.TabIndex = 24;
            this.buttonSuppPersonnel.Text = "Supprimer Personnel";
            this.buttonSuppPersonnel.UseVisualStyleBackColor = true;
            this.buttonSuppPersonnel.Click += new System.EventHandler(this.buttonSuppPersonnel_Click);
            // 
            // Id
            // 
            this.Id.AutoSize = true;
            this.Id.Location = new System.Drawing.Point(763, 85);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(15, 13);
            this.Id.TabIndex = 23;
            this.Id.Text = "id";
            // 
            // textBoxIDTsupp
            // 
            this.textBoxIDTsupp.Location = new System.Drawing.Point(805, 78);
            this.textBoxIDTsupp.Name = "textBoxIDTsupp";
            this.textBoxIDTsupp.Size = new System.Drawing.Size(100, 20);
            this.textBoxIDTsupp.TabIndex = 22;
            // 
            // buttonSuppTech
            // 
            this.buttonSuppTech.CausesValidation = false;
            this.buttonSuppTech.Location = new System.Drawing.Point(791, 133);
            this.buttonSuppTech.Name = "buttonSuppTech";
            this.buttonSuppTech.Size = new System.Drawing.Size(124, 23);
            this.buttonSuppTech.TabIndex = 21;
            this.buttonSuppTech.Text = "Supprimer Technicien";
            this.buttonSuppTech.UseVisualStyleBackColor = true;
            this.buttonSuppTech.Click += new System.EventHandler(this.buttonSuppTech_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(462, 188);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 13);
            this.label20.TabIndex = 20;
            this.label20.Text = "Mot de passe";
            // 
            // textBoxMdpU
            // 
            this.textBoxMdpU.Location = new System.Drawing.Point(539, 181);
            this.textBoxMdpU.Name = "textBoxMdpU";
            this.textBoxMdpU.Size = new System.Drawing.Size(100, 20);
            this.textBoxMdpU.TabIndex = 19;
            // 
            // checkBoxResponsable
            // 
            this.checkBoxResponsable.AutoSize = true;
            this.checkBoxResponsable.Location = new System.Drawing.Point(458, 132);
            this.checkBoxResponsable.Name = "checkBoxResponsable";
            this.checkBoxResponsable.Size = new System.Drawing.Size(88, 17);
            this.checkBoxResponsable.TabIndex = 18;
            this.checkBoxResponsable.Text = "Responsable";
            this.checkBoxResponsable.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(15, 174);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 13);
            this.label19.TabIndex = 17;
            this.label19.Text = "Mot de passe";
            // 
            // textBoxMdpT
            // 
            this.textBoxMdpT.Location = new System.Drawing.Point(108, 167);
            this.textBoxMdpT.Name = "textBoxMdpT";
            this.textBoxMdpT.Size = new System.Drawing.Size(100, 20);
            this.textBoxMdpT.TabIndex = 16;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(455, 81);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(84, 13);
            this.label18.TabIndex = 15;
            this.label18.Text = "Date Embauche";
            // 
            // textBoxDateEmbauche
            // 
            this.textBoxDateEmbauche.Location = new System.Drawing.Point(539, 74);
            this.textBoxDateEmbauche.Name = "textBoxDateEmbauche";
            this.textBoxDateEmbauche.Size = new System.Drawing.Size(100, 20);
            this.textBoxDateEmbauche.TabIndex = 14;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(254, 184);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(68, 13);
            this.label17.TabIndex = 13;
            this.label17.Text = "Nom Prenom";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(260, 133);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(41, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "identite";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(260, 81);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "Matricule";
            // 
            // textBoxNomP
            // 
            this.textBoxNomP.Location = new System.Drawing.Point(328, 178);
            this.textBoxNomP.Name = "textBoxNomP";
            this.textBoxNomP.Size = new System.Drawing.Size(100, 20);
            this.textBoxNomP.TabIndex = 10;
            // 
            // textBoxidentite
            // 
            this.textBoxidentite.Location = new System.Drawing.Point(316, 126);
            this.textBoxidentite.Name = "textBoxidentite";
            this.textBoxidentite.Size = new System.Drawing.Size(100, 20);
            this.textBoxidentite.TabIndex = 9;
            // 
            // textBoxMatricule
            // 
            this.textBoxMatricule.Location = new System.Drawing.Point(316, 71);
            this.textBoxMatricule.Name = "textBoxMatricule";
            this.textBoxMatricule.Size = new System.Drawing.Size(100, 20);
            this.textBoxMatricule.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(33, 126);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 13);
            this.label14.TabIndex = 6;
            this.label14.Text = "Formation";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 81);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 5;
            this.label13.Text = "Niveau intervention";
            // 
            // textBoxNvInter
            // 
            this.textBoxNvInter.Location = new System.Drawing.Point(108, 78);
            this.textBoxNvInter.Name = "textBoxNvInter";
            this.textBoxNvInter.Size = new System.Drawing.Size(100, 20);
            this.textBoxNvInter.TabIndex = 4;
            // 
            // textBoxFormation
            // 
            this.textBoxFormation.Location = new System.Drawing.Point(108, 119);
            this.textBoxFormation.Name = "textBoxFormation";
            this.textBoxFormation.Size = new System.Drawing.Size(100, 20);
            this.textBoxFormation.TabIndex = 3;
            // 
            // buttonAjoutUtilisateur
            // 
            this.buttonAjoutUtilisateur.Location = new System.Drawing.Point(372, 244);
            this.buttonAjoutUtilisateur.Name = "buttonAjoutUtilisateur";
            this.buttonAjoutUtilisateur.Size = new System.Drawing.Size(124, 23);
            this.buttonAjoutUtilisateur.TabIndex = 2;
            this.buttonAjoutUtilisateur.Text = "Ajout Utilisateur";
            this.buttonAjoutUtilisateur.UseVisualStyleBackColor = true;
            this.buttonAjoutUtilisateur.Click += new System.EventHandler(this.buttonAjoutUtilisateur_Click);
            // 
            // buttonAjoutTechnicien
            // 
            this.buttonAjoutTechnicien.Location = new System.Drawing.Point(63, 217);
            this.buttonAjoutTechnicien.Name = "buttonAjoutTechnicien";
            this.buttonAjoutTechnicien.Size = new System.Drawing.Size(124, 23);
            this.buttonAjoutTechnicien.TabIndex = 0;
            this.buttonAjoutTechnicien.Text = "Ajout Technicien";
            this.buttonAjoutTechnicien.UseVisualStyleBackColor = true;
            this.buttonAjoutTechnicien.Click += new System.EventHandler(this.buttonAjoutTechnicien_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.BtCh);
            this.tabPage5.Controls.Add(this.listBoxCh);
            this.tabPage5.Controls.Add(this.AjoutCh);
            this.tabPage5.Controls.Add(this.label37);
            this.tabPage5.Controls.Add(this.Annee);
            this.tabPage5.Controls.Add(this.label36);
            this.tabPage5.Controls.Add(this.specialite);
            this.tabPage5.Controls.Add(this.label35);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.PrenomChercheur);
            this.tabPage5.Controls.Add(this.NomChercheur);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1612, 568);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Ajout chercheur";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // BtCh
            // 
            this.BtCh.Location = new System.Drawing.Point(906, 294);
            this.BtCh.Name = "BtCh";
            this.BtCh.Size = new System.Drawing.Size(126, 30);
            this.BtCh.TabIndex = 51;
            this.BtCh.Text = "Afficher Chercheurs";
            this.BtCh.UseVisualStyleBackColor = true;
            this.BtCh.Click += new System.EventHandler(this.BtCh_Click);
            // 
            // listBoxCh
            // 
            this.listBoxCh.FormattingEnabled = true;
            this.listBoxCh.Location = new System.Drawing.Point(820, 52);
            this.listBoxCh.Name = "listBoxCh";
            this.listBoxCh.Size = new System.Drawing.Size(297, 199);
            this.listBoxCh.TabIndex = 50;
            // 
            // AjoutCh
            // 
            this.AjoutCh.Location = new System.Drawing.Point(548, 174);
            this.AjoutCh.Name = "AjoutCh";
            this.AjoutCh.Size = new System.Drawing.Size(124, 23);
            this.AjoutCh.TabIndex = 49;
            this.AjoutCh.Text = "Ajout Chercheur";
            this.AjoutCh.UseVisualStyleBackColor = true;
            this.AjoutCh.Click += new System.EventHandler(this.AjoutCh_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(327, 276);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(38, 13);
            this.label37.TabIndex = 48;
            this.label37.Text = "Annee";
            // 
            // Annee
            // 
            this.Annee.Location = new System.Drawing.Point(374, 269);
            this.Annee.Name = "Annee";
            this.Annee.Size = new System.Drawing.Size(100, 20);
            this.Annee.TabIndex = 47;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(327, 229);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(51, 13);
            this.label36.TabIndex = 46;
            this.label36.Text = "specialite";
            // 
            // specialite
            // 
            this.specialite.Location = new System.Drawing.Point(374, 222);
            this.specialite.Name = "specialite";
            this.specialite.Size = new System.Drawing.Size(100, 20);
            this.specialite.TabIndex = 45;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(327, 177);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(43, 13);
            this.label35.TabIndex = 44;
            this.label35.Text = "Prenom";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(339, 122);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(29, 13);
            this.label34.TabIndex = 43;
            this.label34.Text = "Nom";
            // 
            // PrenomChercheur
            // 
            this.PrenomChercheur.Location = new System.Drawing.Point(374, 174);
            this.PrenomChercheur.Name = "PrenomChercheur";
            this.PrenomChercheur.Size = new System.Drawing.Size(100, 20);
            this.PrenomChercheur.TabIndex = 42;
            // 
            // NomChercheur
            // 
            this.NomChercheur.Location = new System.Drawing.Point(374, 119);
            this.NomChercheur.Name = "NomChercheur";
            this.NomChercheur.Size = new System.Drawing.Size(100, 20);
            this.NomChercheur.TabIndex = 41;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 658);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonAjoutMateriel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBoxDateAchat;
        private System.Windows.Forms.TextBox textBoxProcesseur;
        private System.Windows.Forms.TextBox textBoxLogiciel;
        private System.Windows.Forms.TextBox textBoxMemoire;
        private System.Windows.Forms.TextBox textBoxType;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxsuppMat;
        private System.Windows.Forms.Button buttonSupprimerMateriel;
        private System.Windows.Forms.Button buttonAfficherMateriel;
        private System.Windows.Forms.ListBox listBoxMateriel;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button buttonConsulterIncidents;
        private System.Windows.Forms.Button buttonModifierEtat;
        private System.Windows.Forms.TextBox textBoxEtat;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxTravailE;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button buttonAjoutUtilisateur;
        private System.Windows.Forms.Button buttonAjoutTechnicien;
        private System.Windows.Forms.TextBox textBoxNvInter;
        private System.Windows.Forms.TextBox textBoxFormation;
        private System.Windows.Forms.TextBox textBoxNomP;
        private System.Windows.Forms.TextBox textBoxidentite;
        private System.Windows.Forms.TextBox textBoxMatricule;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxDateEmbauche;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxMdpU;
        private System.Windows.Forms.CheckBox checkBoxResponsable;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBoxMdpT;
        private System.Windows.Forms.Label Id;
        private System.Windows.Forms.TextBox textBoxIDTsupp;
        private System.Windows.Forms.Button buttonSuppTech;
        private System.Windows.Forms.Button buttonModifierTech;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxIDPSupp;
        private System.Windows.Forms.Button buttonSuppPersonnel;
        private System.Windows.Forms.TextBox textBoxModifUtili;
        private System.Windows.Forms.Button buttonModifierUtilisateur;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxModifFormT;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBoxIdmodifU;
        private System.Windows.Forms.TextBox textBoxIdModifT;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button buttonConnexion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxFourniseur;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBoxRegion;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxIdT;
        private System.Windows.Forms.ListBox listBoxIncidents;
        private System.Windows.Forms.Button buttonDeclarer;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBoxDate1;
        private System.Windows.Forms.TextBox textBoxTypeD;
        private System.Windows.Forms.TextBox textBoxEtat1;
        private System.Windows.Forms.TextBox textBoxUrgence;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox PrenomChercheur;
        private System.Windows.Forms.TextBox NomChercheur;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button BtCh;
        private System.Windows.Forms.ListBox listBoxCh;
        private System.Windows.Forms.Button AjoutCh;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox Annee;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox specialite;
    }
}

