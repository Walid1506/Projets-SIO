package com.example.projeta;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Cette classe est utilisée pour gérer la base de données SQLite dans l'application.
 * Elle permet de créer, mettre à jour et manipuler des données dans les tables "professionnel_table" et "rdv_table".
 */
public class BD extends SQLiteOpenHelper {

    public static final String ProjetA = "ProjetA.db";
    public static final String professionnel = "professionnel_table";
    public static final String idP = "ID";
    public static final String nom = "NOM";
    public static final String prenom = "PRENOM";
    public static final String types = "TYPES";
    public static final String adresse = "ADRESSES";
    public static final String mail = "MAIL";
    public static final String tel = "TEL";

    public static final String rdvTable = "rdv_table";
    public static final String idRdv = "IDRDV";
    public static final String dateRdv = "DATERDV";
    public static final String heureRdv = "HEURERDV";
    public static final String proRdv = "PRORDV";

    /**
     * Constructeur de la classe BD.
     *
     * @param context Le contexte dans lequel la base de données est utilisée.
     */
    public BD(Context context) {
        super(context, ProjetA, null, 1);
    }

    /**
     * Crée les tables "professionnel_table" et "rdv_table" dans la base de données.
     *
     * @param db La base de données SQLite.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + professionnel + " (" +
                idP + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                nom + " TEXT, " +
                prenom + " TEXT, " +
                types + " TEXT, " +
                adresse + " TEXT, " +
                mail + " TEXT, " +
                tel + " TEXT)");

        db.execSQL("CREATE TABLE " + rdvTable + " (" +
                idRdv + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                dateRdv + " TEXT, " +
                heureRdv + " TEXT, " +
                proRdv + " TEXT)");
    }

    /**
     * Met à jour la base de données en supprimant les tables existantes et en recréant les tables.
     *
     * @param db La base de données SQLite.
     * @param oldVersion La version ancienne de la base de données.
     * @param newVersion La nouvelle version de la base de données.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + professionnel);
        db.execSQL("DROP TABLE IF EXISTS " + rdvTable);
        onCreate(db);
    }

    /**
     * Insère un professionnel dans la table "professionnel_table".
     *
     * @param nom Le nom du professionnel.
     * @param prenom Le prénom du professionnel.
     * @param types Le type de professionnel.
     * @param adresse L'adresse du professionnel.
     * @param mail L'email du professionnel.
     * @param tel Le numéro de téléphone du professionnel.
     */
    public void insertProfessionnel(String nom, String prenom, String types, String adresse, String mail, String tel) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(BD.nom, nom);
        cv.put(BD.prenom, prenom);
        cv.put(BD.types, types);
        cv.put(BD.adresse, adresse);
        cv.put(BD.mail, mail);
        cv.put(BD.tel, tel);
        db.insert(professionnel, null, cv);
        db.close();
    }

    /**
     * Insère un rendez-vous dans la table "rdv_table" après avoir vérifié qu'un rendez-vous similaire n'existe pas déjà.
     *
     * @param dateRdv La date du rendez-vous.
     * @param heureRdv L'heure du rendez-vous.
     * @param proRdv Le professionnel associé au rendez-vous.
     */
    public void insererRDV(String dateRdv, String heureRdv, String proRdv) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv2 = new ContentValues();
        cv2.put(BD.dateRdv, dateRdv);
        cv2.put(BD.heureRdv, heureRdv);
        cv2.put(BD.proRdv, proRdv);

        String selection = BD.dateRdv + " = ? AND " + BD.heureRdv + " = ? AND " + BD.proRdv + " = ?";
        String[] selectionArgs = {dateRdv, heureRdv, proRdv};

        Cursor cursor = db.query(rdvTable, null, selection, selectionArgs, null, null, null);

        if (cursor.getCount() == 0) {
            db.insert(rdvTable, null, cv2);
        }

        cursor.close();
        db.close();
    }

    /**
     * Récupère toutes les données des professionnels.
     *
     * @return Un curseur contenant toutes les données de la table des professionnels.
     */
    public Cursor getProfessionnelData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + professionnel, null);
    }

    /**
     * Recherche les professionnels ayant une adresse spécifique.
     *
     * @param query L'adresse à rechercher.
     * @return Un curseur contenant les professionnels correspondant à l'adresse.
     */
    public Cursor getListePro(String query) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT " + nom + ", " + prenom + " FROM " + professionnel + " WHERE " + adresse + " = ?",
                new String[]{query});
    }

    /**
     * Recherche des données dans une table spécifiée avec des critères donnés.
     *
     * @param table Le nom de la table à interroger.
     * @param colonnes Les colonnes à récupérer.
     * @param condition La condition WHERE pour la recherche.
     * @param dateR Les arguments pour la condition WHERE.
     * @param heureR La colonne de tri des résultats.
     * @return Un curseur contenant les résultats de la requête.
     */
    public Cursor rechercher(String table, String[] colonnes, String condition, String[] dateR, String heureR) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            String query = "SELECT " + String.join(", ", colonnes) +
                    " FROM " + table +
                    " WHERE " + condition +
                    " ORDER BY " + heureR;

            cursor = db.rawQuery(query, dateR);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cursor;
    }
}
