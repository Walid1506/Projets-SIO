package com.example.projeta;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.database.Cursor;
import java.util.ArrayList;

/**
 * Classe représentant l'écran permettant de rechercher des professionnels par adresse.
 * Permet à l'utilisateur de saisir une adresse et de trouver les professionnels correspondants.
 */
public class Rechercher_professionnels extends AppCompatActivity {

    private BD db;
    private Spinner listePro;
    private EditText adresse;
    private Button rechercher;

    /**
     * Méthode appelée lors de la création de l'activité.
     * Initialise les composants de l'interface utilisateur et configure le bouton de recherche.
     *
     * @param savedInstanceState État sauvegardé de l'activité (si applicable).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rechercher_professionnels);

        db = new BD(this);
        listePro = findViewById(R.id.listePro);
        adresse = findViewById(R.id.adresse);
        rechercher = findViewById(R.id.rechercher);

        // Configure le bouton de recherche
        rechercher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rechercherProfessionnels();
            }
        });
    }

    /**
     * Recherche les professionnels dans la base de données en fonction de l'adresse saisie.
     * Affiche les résultats dans un Spinner. Si aucun professionnel n'est trouvé, un message est affiché.
     */
    private void rechercherProfessionnels() {
        String query = adresse.getText().toString().trim(); // Récupère l'adresse saisie par l'utilisateur

        // Si l'adresse n'est pas vide
        if (!query.isEmpty()) {
            // Effectue la recherche des professionnels en fonction de l'adresse
            Cursor cursor = db.getListePro(query);
            ArrayList<String> resultats = new ArrayList<>();

            // Ajoute les résultats à la liste
            while (cursor.moveToNext()) {
                String nom = cursor.getString(0); // Récupère le nom du professionnel
                String prenom = cursor.getString(1); // Récupère le prénom du professionnel
                resultats.add(nom + " " + prenom); // Ajoute le nom et prénom dans la liste
            }

            // Si aucun résultat n'est trouvé
            if (resultats.isEmpty()) {
                resultats.add("Aucun professionnel trouvé");
            }
            cursor.close();

            // Met à jour le Spinner avec les résultats trouvés
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, resultats);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            listePro.setAdapter(adapter);
        }
    }

    /**
     * Méthode pour revenir à l'écran principal.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void Retour(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
}
