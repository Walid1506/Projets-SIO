package com.example.projeta;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.EditText;
import android.view.View;

/**
 * Classe représentant l'écran permettant d'enregistrer un professionnel.
 */
public class enregistrer extends AppCompatActivity {

    /** Instance de la base de données. */
    BD db;

    /** Champs pour saisir les informations du professionnel. */
    private EditText nom, prenom, adresse, mail, tel, types;

    /**
     * Méthode appelée lors de la création de l'activité.
     * Initialise les composants de l'interface utilisateur et la base de données.
     *
     * @param savedInstanceState État sauvegardé de l'activité (si applicable).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enregistrer);

        // Ajuster les marges pour tenir compte des barres système.
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialisation de la base de données.
        db = new BD(this);

        // Initialisation des champs de saisie.
        nom = findViewById(R.id.nom);
        prenom = findViewById(R.id.prenom);
        types = findViewById(R.id.types);
        adresse = findViewById(R.id.adresse);
        mail = findViewById(R.id.mail);
        tel = findViewById(R.id.tel);
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Enregistrer".
     * Insère les informations du professionnel dans la base de données.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void InsertionInfo(View view) {
        db.insertProfessionnel(
                nom.getText().toString(),
                prenom.getText().toString(),
                types.getText().toString(),
                adresse.getText().toString(),
                mail.getText().toString(),
                tel.getText().toString()
        );
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Retour".
     * Redirige vers l'écran principal.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void Retour(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
}
