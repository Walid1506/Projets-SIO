package com.example.projeta;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

/**
 * Classe représentant l'écran principal de l'application.
 * Cette activité permet de naviguer vers les différentes sections de l'application.
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Méthode appelée lors de la création de l'activité.
     * Initialise l'interface utilisateur et gère les barres système (par exemple, la barre de statut).
     *
     * @param savedInstanceState État sauvegardé de l'activité (si applicable).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Ajuste les marges pour tenir compte des barres système.
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Enregistrer".
     * Redirige vers l'écran permettant d'enregistrer un professionnel.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void enregistrer(View view) {
        Intent intent2 = new Intent(this, enregistrer.class);
        startActivity(intent2);
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Prendre RDV".
     * Redirige vers l'écran permettant de prendre un rendez-vous.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void prendreRdv(View view) {
        Intent intent2 = new Intent(this, prendreRdv.class);
        startActivity(intent2);
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Afficher Professionnels".
     * Redirige vers l'écran permettant de rechercher des professionnels.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void AfficherP(View view) {
        Intent intent2 = new Intent(this, Rechercher_professionnels.class);
        startActivity(intent2);
    }

    /**
     * Méthode appelée lorsqu'on clique sur le bouton "Planning".
     * Redirige vers l'écran permettant d'afficher le planning des rendez-vous.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void planning(View view) {
        Intent intent2 = new Intent(this, planning.class);
        startActivity(intent2);
    }
}
