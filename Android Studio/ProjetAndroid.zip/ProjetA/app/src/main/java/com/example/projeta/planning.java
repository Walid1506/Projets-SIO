package com.example.projeta;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Classe représentant l'écran permettant de visualiser les rendez-vous pour une date donnée.
 * L'utilisateur peut sélectionner une date via un calendrier et afficher les rendez-vous associés.
 */
public class planning extends AppCompatActivity {

    private ListView listViewPlanning;   // Liste des rendez-vous à afficher
    private Button btnDate, btnAfficherRdv;  // Boutons pour sélectionner la date et afficher les RDV
    private BD db;  // Objet pour accéder à la base de données
    private ArrayAdapter<String> adapter; // Adaptateur pour afficher la liste des rendez-vous
    private String selectedDate;  // Date sélectionnée par l'utilisateur

    /**
     * Méthode appelée lors de la création de l'activité.
     * Initialise les composants de l'interface utilisateur et les événements des boutons.
     *
     * @param savedInstanceState État sauvegardé de l'activité (si applicable).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planning);

        // Initialisation des vues
        listViewPlanning = findViewById(R.id.listViewPlanning);
        btnDate = findViewById(R.id.btnDate);
        btnAfficherRdv = findViewById(R.id.btnAfficherRdv);
        db = new BD(this);

        // Événement pour le bouton "Sélectionner la date"
        btnDate.setOnClickListener(v -> showDatePickerDialog());

        // Événement pour le bouton "Afficher les rendez-vous"
        btnAfficherRdv.setOnClickListener(v -> afficherRDV(selectedDate));
    }

    /**
     * Méthode pour afficher le sélecteur de date via un dialogue.
     * Permet à l'utilisateur de choisir une date pour afficher les rendez-vous associés.
     */
    private void showDatePickerDialog() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // Ouvre un dialogue pour sélectionner une date
        new DatePickerDialog(this, (view, selectedYear, selectedMonth, selectedDay) -> {
            // Formate la date choisie en "YYYY-MM-DD"
            selectedDate = String.format(Locale.getDefault(), "%04d-%02d-%02d",
                    selectedYear, selectedMonth + 1, selectedDay);
        }, year, month, day).show();
    }

    /**
     * Méthode pour afficher les rendez-vous pour la date sélectionnée.
     * Effectue une requête sur la base de données et affiche les rendez-vous dans la liste.
     *
     * @param date La date pour laquelle les rendez-vous doivent être affichés.
     */
    private void afficherRDV(String date) {
        String[] colonnes = {BD.dateRdv, BD.heureRdv, BD.proRdv}; // Colonnes à récupérer
        String condition = BD.dateRdv + " = ?"; // Filtre par date
        String[] dateR = {date};  // Paramètre de la date sélectionnée
        String heureR = BD.heureRdv + " ASC";  // Tri des résultats par heure

        // Effectue la requête dans la base de données
        Cursor cursor = db.rechercher(BD.rdvTable, colonnes, condition, dateR, heureR);
        List<String> rdvListe = new ArrayList<>();  // Liste des rendez-vous

        // Ajoute chaque rendez-vous à la liste
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String rdvInfo = "Professionnel : " + cursor.getString(cursor.getColumnIndexOrThrow(BD.proRdv)) +
                        " - Heure : " + cursor.getString(cursor.getColumnIndexOrThrow(BD.heureRdv));
                rdvListe.add(rdvInfo);
            }
            cursor.close();
        }

        // Si aucun rendez-vous n'est trouvé, affiche un message
        if (rdvListe.isEmpty()) {
            rdvListe.add("Aucun rendez-vous pour cette date.");
        }

        // Met à jour l'adaptateur de la liste avec les résultats
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rdvListe);
        listViewPlanning.setAdapter(adapter);
    }

    /**
     * Méthode pour revenir à l'écran principal.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void retour(View view) {
        startActivity(new Intent(this, MainActivity.class));  // Lance l'écran principal
    }
}
