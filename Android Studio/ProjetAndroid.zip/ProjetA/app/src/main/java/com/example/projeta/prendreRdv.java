package com.example.projeta;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.Spinner;
import android.database.Cursor;
import android.widget.TextView;
import android.util.Log;

import java.util.ArrayList;

/**
 * Classe représentant l'écran permettant de prendre un rendez-vous.
 * Permet de sélectionner une date, une heure et un professionnel pour prendre un rendez-vous.
 */
public class prendreRdv extends AppCompatActivity {

    private BD db;
    private CalendarView calendarView;
    private TextView test;
    private String[] HeureRdv = {"8h", "8h30", "9h", "9h30", "10h", "10h30", "11h", "11h30", "13h30", "14h", "14h30", "15h", "15h30", "16h", "16h30"};
    private Spinner spinHeure, spinPro;
    private int HeureSelect;
    private String selectDate, selectPro;

    /**
     * Méthode appelée lors de la création de l'activité.
     * Initialise les composants de l'interface utilisateur et configure les écouteurs pour les sélecteurs.
     *
     * @param savedInstanceState État sauvegardé de l'activité (si applicable).
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prendre_rdv);

        db = new BD(this);

        spinHeure = findViewById(R.id.heureRdv);
        spinPro = findViewById(R.id.pro);
        calendarView = findViewById(R.id.calendarView);
        test = findViewById(R.id.test);

        // Initialisation de l'adaptateur pour le Spinner Heure
        ArrayAdapter<String> heure = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, HeureRdv);
        heure.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinHeure.setAdapter(heure);

        // Écouteur pour le Spinner Heure
        spinHeure.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                HeureSelect = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Rien à faire
            }
        });

        // Écouteur pour le calendrier
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth); // Format : yyyy-MM-dd
        });

        // Écouteur pour le Spinner Professionnel
        spinPro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectPro = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Rien à faire
            }
        });

        // Chargement des professionnels à partir de la base de données
        getProfessionnelData();
    }

    /**
     * Récupère les données des professionnels à partir de la base de données et les affiche dans le Spinner.
     */
    public void getProfessionnelData() {
        try {
            Cursor data = db.getProfessionnelData();
            ArrayList<String> proListe = new ArrayList<>();
            while (data.moveToNext()) {
                String info = data.getString(1) + " " + data.getString(2) + " " + data.getString(3); // Nom + Prénom
                proListe.add(info);
            }
            data.close();

            // Remplissage du Spinner avec la liste des professionnels
            ArrayAdapter<String> listePro = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, proListe);
            listePro.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinPro.setAdapter(listePro);
        } catch (Exception e) {
            // Gestion des erreurs
        }
    }

    /**
     * Insère un rendez-vous dans la base de données.
     *
     * @param date La date du rendez-vous.
     * @param heure L'heure du rendez-vous.
     * @param pro Le professionnel associé au rendez-vous.
     */
    private void insererRDV(String date, String heure, String pro) {
        try {
            db.insererRDV(date, heure, pro);
        } catch (Exception e) {
            // Gestion des erreurs
        }
    }

    /**
     * Méthode appelée lors du clic sur le bouton "Prendre RDV".
     * Vérifie les informations saisies et insère le rendez-vous dans la base de données si tout est valide.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void prendreRDV(View view) {
        try {
            if (selectDate != null && !selectDate.isEmpty() && HeureSelect >= 0 && selectPro != null && !selectPro.isEmpty()) {
                String heureR = HeureRdv[HeureSelect];

                insererRDV(selectDate, heureR, selectPro);
                test.setText("Rendez-vous pris avec succès pour le " + selectDate + " à " + heureR + " avec " + selectPro);
            } else {
                test.setText("Sélectionnez tous les champs.");
            }
        } catch (Exception e) {
            // Gestion des erreurs
        }
    }

    /**
     * Méthode pour revenir à l'écran principal.
     *
     * @param view La vue qui a déclenché cet événement.
     */
    public void Retour(View view) {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
}
